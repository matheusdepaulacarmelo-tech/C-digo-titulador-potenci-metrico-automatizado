"""Processamento de titulação potenciométrica (dados registrados em CSV).

Uso:
    python processamento_titulacao.py titulacao.csv

O CSV deve conter as colunas "Volume" (mL) e "Potencial" (mV ou V).
Colunas adicionais, como "Temperatura" e "Tempo", são permitidas.

Instalação das dependências:
    pip install numpy pandas matplotlib
"""

from pathlib import Path
import argparse
import sys

import matplotlib
matplotlib.use("Agg")  # Salva gráficos mesmo sem abrir janela gráfica.
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


def ler_dados(caminho: Path) -> tuple[np.ndarray, np.ndarray]:
    """Lê CSV com vírgula ou ponto e vírgula como separador."""
    if not caminho.is_file():
        raise FileNotFoundError(f"Arquivo não encontrado: {caminho}")

    tabela = pd.read_csv(caminho, sep=None, engine="python", encoding="utf-8-sig")
    tabela.columns = [str(c).strip() for c in tabela.columns]
    colunas = {c.casefold(): c for c in tabela.columns}

    if "volume" not in colunas or "potencial" not in colunas:
        raise ValueError(
            "O CSV precisa ter colunas chamadas 'Volume' e 'Potencial'. "
            f"Colunas encontradas: {', '.join(tabela.columns)}"
        )

    def converter_numeros(coluna: str) -> pd.Series:
        # Aceita números como 2.5 e 2,5 (com separador CSV compatível).
        valores = tabela[coluna].astype(str).str.strip().str.replace(",", ".", regex=False)
        return pd.to_numeric(valores, errors="coerce")

    dados = pd.DataFrame({
        "Volume": converter_numeros(colunas["volume"]),
        "Potencial": converter_numeros(colunas["potencial"]),
    })
    total = len(dados)
    dados = dados.replace([np.inf, -np.inf], np.nan).dropna()
    if len(dados) < total:
        print(f"Aviso: {total - len(dados)} linha(s) com dados inválidos foram ignoradas.")

    if len(dados) < 4:
        raise ValueError("São necessários pelo menos 4 pares válidos de volume e potencial.")

    if not dados["Volume"].is_monotonic_increasing:
        print("Aviso: os dados não estavam em ordem crescente; serão ordenados por volume.")
        dados = dados.sort_values("Volume")

    V = dados["Volume"].to_numpy(dtype=float)
    E = dados["Potencial"].to_numpy(dtype=float)
    if np.any(np.diff(V) <= 0):
        raise ValueError("Os volumes precisam ser diferentes e crescentes (sem repetição).")
    return V, E


def ponto_equivalencia_segunda_derivada(
    volume_d2: np.ndarray, derivada2: np.ndarray, referencia: float
) -> float | None:
    """Interpola mudanças de sinal da segunda derivada e seleciona a mais próxima do pico da primeira."""
    candidatos = []
    for i in range(len(derivada2) - 1):
        x0, x1 = volume_d2[i], volume_d2[i + 1]
        y0, y1 = derivada2[i], derivada2[i + 1]
        if y0 == 0:
            candidatos.append(float(x0))
        elif (y0 < 0 < y1) or (y0 > 0 > y1):
            candidatos.append(float(x0 - y0 * (x1 - x0) / (y1 - y0)))
    if derivada2[-1] == 0:
        candidatos.append(float(volume_d2[-1]))
    if not candidatos:
        return None
    return min(candidatos, key=lambda v: abs(v - referencia))


def salvar_grafico(x, y, titulo, rotulo_y, destino, veq=None):
    fig, ax = plt.subplots(figsize=(8, 5))
    ax.plot(x, y, marker="o", markersize=3, linewidth=1.4)
    if veq is not None:
        ax.axvline(veq, linestyle="--", linewidth=1.2,
                   label=f"Veq estimado = {veq:.3f} mL")
        ax.legend()
    ax.set_title(titulo)
    ax.set_xlabel("Volume de titulante (mL)")
    ax.set_ylabel(rotulo_y)
    ax.grid(True, alpha=0.3)
    fig.tight_layout()
    fig.savefig(destino, dpi=200)
    plt.close(fig)


def processar(caminho: Path, unidade: str):
    V, E = ler_dados(caminho)

    # Primeira derivada numérica: diferença entre pontos consecutivos.
    dE_dV = np.diff(E) / np.diff(V)
    V_d1 = (V[:-1] + V[1:]) / 2

    # Segunda derivada numérica: diferença entre valores da primeira derivada.
    d2E_dV2 = np.diff(dE_dV) / np.diff(V_d1)
    V_d2 = (V_d1[:-1] + V_d1[1:]) / 2

    # Método 1: maior módulo da primeira derivada.
    indice = int(np.argmax(np.abs(dE_dV)))
    veq_1 = float(V_d1[indice])

    # Método 2: cruzamento por zero da segunda derivada, próximo ao pico.
    veq_2 = ponto_equivalencia_segunda_derivada(V_d2, d2E_dV2, veq_1)

    pasta = caminho.parent / "resultados_titulacao"
    pasta.mkdir(parents=True, exist_ok=True)

    # Preserva os valores originais em arquivo separado dos cálculos.
    pd.DataFrame({"Volume": V, "Potencial": E}).to_csv(
        pasta / "dados_ordenados.csv", index=False
    )
    pd.DataFrame({"Volume_d1": V_d1, "Primeira_derivada": dE_dV}).to_csv(
        pasta / "primeira_derivada.csv", index=False
    )
    pd.DataFrame({"Volume_d2": V_d2, "Segunda_derivada": d2E_dV2}).to_csv(
        pasta / "segunda_derivada.csv", index=False
    )

    salvar_grafico(V, E, "Curva de titulação potenciométrica",
                   f"Potencial ({unidade})", pasta / "curva_titulacao.png", veq_1)
    salvar_grafico(V_d1, dE_dV, "Primeira derivada",
                   f"dE/dV ({unidade}/mL)", pasta / "primeira_derivada.png", veq_1)
    salvar_grafico(V_d2, d2E_dV2, "Segunda derivada",
                   f"d²E/dV² ({unidade}/mL²)", pasta / "segunda_derivada.png", veq_2)

    linhas = [
        "RESULTADOS DA TITULAÇÃO POTENCIOMÉTRICA",
        f"Arquivo analisado: {caminho.name}",
        f"Pontos válidos: {len(V)}",
        f"Volume de equivalência (1ª derivada): {veq_1:.4f} mL",
        "Volume de equivalência (2ª derivada): "
        + (f"{veq_2:.4f} mL" if veq_2 is not None else "não identificado"),
        "Observação: estimativas numéricas; verificar visualmente a curva e o ruído.",
    ]
    (pasta / "resultado.txt").write_text("\n".join(linhas) + "\n", encoding="utf-8")
    print("\n".join(linhas))
    print(f"\nGráficos, tabelas e resultado salvos em: {pasta}")
    if indice == 0 or indice == len(dE_dV) - 1:
        print("Aviso: o máximo da 1ª derivada está no extremo dos dados; "
              "talvez a região de equivalência não tenha sido inteiramente medida.")
    if veq_2 is None:
        print("Aviso: não foi encontrado cruzamento por zero da 2ª derivada.")


def main():
    parser = argparse.ArgumentParser(description="Analisa curva potenciométrica e derivadas.")
    parser.add_argument("csv", nargs="?", default="titulacao.csv",
                        help="arquivo com as colunas Volume e Potencial (padrão: titulacao.csv)")
    parser.add_argument("--unidade", choices=["mV", "V"], default="mV",
                        help="unidade do potencial no CSV, usada nos gráficos (padrão: mV)")
    args = parser.parse_args()
    try:
        processar(Path(args.csv).expanduser().resolve(), args.unidade)
    except (OSError, ValueError, pd.errors.ParserError) as erro:
        print(f"Erro: {erro}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
